#!/bin/sh
git ls-files -oi --exclude-per-directory=.gitignore
